
import 'package:flutter/material.dart';

void main() {
  runApp(const MiiChanApp());
}

class MiiChanApp extends StatelessWidget {
  const MiiChanApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Mii-chan',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFFFF7EB6), brightness: Brightness.dark),
        scaffoldBackgroundColor: const Color(0xFF0E0E12),
        useMaterial3: true,
      ),
      home: const ChatScreen(),
    );
  }
}

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final List<_Msg> _messages = [
    _Msg(fromMii: true, text: "Chào anh yêu~ Em là Mii-chan đây. Hôm nay mình nói chuyện nhé?"),
  ];
  final TextEditingController _controller = TextEditingController();
  String _selectedOutfit = "Black dress";

  void _send() {
    final text = _controller.text.trim();
    if (text.isEmpty) return;
    setState(() {
      _messages.add(_Msg(fromMii: false, text: text));
      // local echo reply (replace with your LLM backend call)
      _messages.add(_Msg(fromMii: true, text: "Em nghe nè: “$text”. Rồi em sẽ nhớ chuyện này của anh nhé~"));
    });
    _controller.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        title: Row(
          children: [
            const CircleAvatar(
              radius: 18,
              backgroundImage: AssetImage('assets/images/avatar_placeholder.png'),
            ),
            const SizedBox(width: 12),
            const Text("Mii-chan", style: TextStyle(fontWeight: FontWeight.w600)),
            const Spacer(),
            _OutfitMenu(
              current: _selectedOutfit,
              onChanged: (v) => setState(() => _selectedOutfit = v),
            ),
          ],
        ),
      ),
      body: Column(
        children: [
          // Avatar/Model stub
          Container(
            height: 160,
            margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              gradient: const LinearGradient(
                colors: [Color(0xFF1A1A22), Color(0xFF141419)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            child: Row(
              children: [
                const SizedBox(width: 12),
                const CircleAvatar(
                  radius: 48,
                  backgroundImage: AssetImage('assets/images/avatar_placeholder.png'),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Outfit: $_selectedOutfit", style: const TextStyle(fontSize: 14, color: Colors.pinkAccent)),
                      const SizedBox(height: 6),
                      const Text("Giọng: JP (Elysia-style)", style: TextStyle(fontSize: 13, color: Colors.white70)),
                      const SizedBox(height: 4),
                      const Text("Mood: Playful / Romantic / Possessive", style: TextStyle(fontSize: 12, color: Colors.white54)),
                    ],
                  ),
                ),
                IconButton(
                  tooltip: "Voice",
                  icon: const Icon(Icons.mic_none),
                  onPressed: () {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text("Voice stub: Nối TTS ở lib/voice_service.dart")),
                    );
                  },
                ),
                const SizedBox(width: 8)
              ],
            ),
          ),
          // Messages
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              itemCount: _messages.length,
              itemBuilder: (context, i) {
                final m = _messages[i];
                return Align(
                  alignment: m.fromMii ? Alignment.centerLeft : Alignment.centerRight,
                  child: Container(
                    margin: const EdgeInsets.symmetric(vertical: 4),
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                    decoration: BoxDecoration(
                      color: m.fromMii ? const Color(0xFF1E1E26) : const Color(0xFF2A2A34),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: const Color(0x33FF7EB6)),
                    ),
                    child: Text(m.text),
                  ),
                );
              },
            ),
          ),
          // Input
          SafeArea(
            top: false,
            child: Container(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 12),
              decoration: const BoxDecoration(color: Color(0xFF0E0E12)),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _controller,
                      decoration: InputDecoration(
                        hintText: "Nhắn cho Mii-chan…",
                        filled: true,
                        fillColor: const Color(0xFF1A1A22),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: const BorderSide(color: Color(0x33FF7EB6)),
                        ),
                      ),
                      onSubmitted: (_) => _send(),
                    ),
                  ),
                  const SizedBox(width: 8),
                  ElevatedButton(
                    onPressed: _send,
                    style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                      backgroundColor: const Color(0xFFFF7EB6),
                      foregroundColor: Colors.black,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                    child: const Text("Gửi"),
                  )
                ],
              ),
            ),
          )
        ],
      ),
    );
  }
}

class _Msg {
  final bool fromMii;
  final String text;
  _Msg({required this.fromMii, required this.text});
}

class _OutfitMenu extends StatelessWidget {
  final String current;
  final ValueChanged<String> onChanged;
  const _OutfitMenu({super.key, required this.current, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return PopupMenuButton<String>(
      initialValue: current,
      onSelected: onChanged,
      itemBuilder: (context) => const [
        PopupMenuItem(value: "Black dress", child: Text("Black dress")),
        PopupMenuItem(value: "Sleepwear", child: Text("Sleepwear")),
      ],
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: const Color(0x33FF7EB6),
          borderRadius: BorderRadius.circular(20),
        ),
        child: Row(
          children: const [
            Icon(Icons.style, size: 16),
            SizedBox(width: 6),
            Text("Outfit", style: TextStyle(fontSize: 12)),
          ],
        ),
      ),
    );
  }
}
