
# Mii-chan — AI Companion (Android APK Starter)

This is a **starter project** so you (or your dev) can build an **APK** on your machine.
It uses **Flutter** for fast Android builds and a Grok-like dark UI with pink accents.

## Features in this Starter
- Dark + pink chat UI (mobile-first)
- Text chat with local echo (replace with your LLM backend later)
- **Outfit selector stub** (e.g., "Black dress", "Sleepwear")
- Voice mode button (hook to TTS later)
- Memory schema and example JP voice lines (Elysia-like moods)
- Lightweight web mock to preview palette (no build needed)

---

## How to Build APK (Step-by-Step)

1. Install Flutter: https://docs.flutter.dev/get-started/install
2. In Android Studio, install the **Android SDK** and set up an **Android device** or emulator.
3. In terminal, go to the `flutter` folder:
   ```bash
   cd flutter
   flutter pub get
   flutter run        # test on a device/emulator
   flutter build apk  # produce app APK
   ```
4. The release APK will be at:
   `flutter/build/app/outputs/flutter-apk/app-release.apk`

> If you need **voice (Japanese TTS)** and **LLM chat**, connect your APIs in `lib/chat_service.dart` and `lib/voice_service.dart` (stubs are included).

---

## Folder Layout
- `flutter/` — the mobile app (Flutter)
- `web_mock/` — quick HTML mock of the color palette & layout
- `prompts/` — example prompts for persona/moods
- `design/` — notes and references

---

## Notes
- This starter ships **without proprietary model files**. Replace stubs with your own backends (OpenAI/xAI/Anthropic/etc.).
- Use `assets/config/memory_schema.json` to persist your custom memories.
- Japanese voice lines are in `assets/voices/voice_lines_jp.txt`.
